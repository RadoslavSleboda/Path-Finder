package FindPathPackage;
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;  
public class FindPathFromFile 
{  
public static void main(String []args)  
{  
try  
{  

FileInputStream fis=new FileInputStream("myFile5.txt");       
Scanner sc=new Scanner(fis);
ArrayList<String> mapSetup = new ArrayList<String>();
int sVertical = 0;
int sHorizontal = 0;
int xVertical = 0;
int xHorizontal = 0;



while(sc.hasNextLine())  
{  
String line = sc.nextLine();
mapSetup.add(line);
}  

sc.close(); 

char[][] map = new char[mapSetup.size()][mapSetup.get(0).length()];
char findS = '.';

for(int i = 0; i < map.length; i++) {
	for(int j = 0; j < map[0].length; j++) {
		map[i][j] = mapSetup.get(i).charAt(j);
	findS = map[i][j];
	if (findS == 'S') {
		sVertical = i;
		sHorizontal = j;
	}
	if (findS == 'X') {
		xVertical = i;
		xHorizontal = j;
		findS = '.';
	}
	map[i][j] = findS;
	
}
}


findPath(sVertical, sHorizontal, map, xVertical, xHorizontal);

}  
catch(IOException e)  
{  
e.printStackTrace();  
}  
} 
public static void findPath(int sVertical, int sHorizontal, char[][] map, int xVertical, int xHorizontal) {
	mark(sVertical, sHorizontal, map);
	
	if(sVertical == xVertical && sHorizontal == xHorizontal) {
		for(int i = 0; i < map.length; i++) {
			System.out.println("");
			for(int j = 0; j < map[0].length; j++) {
				System.out.print(map[i][j]);
			}
			}
		System.exit(0);
	}
	
	if(downPriority(sVertical, sHorizontal, map) == 0 && sVertical < xVertical) {
		down(sVertical, sHorizontal, map, xVertical, xHorizontal);
	} else if(rightPriority(sVertical, sHorizontal, map) == 0 && sHorizontal < xHorizontal) {
		right(sVertical, sHorizontal, map, xVertical, xHorizontal);
	} else if(upPriority(sVertical, sHorizontal, map) == 0 && sVertical > xVertical) {
		up(sVertical, sHorizontal, map, xVertical, xHorizontal);
	} else if(leftPriority(sVertical, sHorizontal, map) == 0 && sHorizontal > xHorizontal) {
		left(sVertical, sHorizontal, map, xVertical, xHorizontal);
	 } else {
		 
		 for(int i = 0; i < 9; i++) {
	 if(downPriority(sVertical, sHorizontal, map) == i) {
		down(sVertical, sHorizontal, map, xVertical, xHorizontal);
		return;
	} else if(rightPriority(sVertical, sHorizontal, map) == i) {
		right(sVertical, sHorizontal, map, xVertical, xHorizontal);
		return;
	} else if(upPriority(sVertical, sHorizontal, map) ==  i) {
		up(sVertical, sHorizontal, map, xVertical, xHorizontal);
		return;
	} else if(leftPriority(sVertical, sHorizontal, map) == i) {
		left(sVertical, sHorizontal, map, xVertical, xHorizontal);
		return;
	} 
	}
		 System.out.println("");
		 System.out.println("There is no clear path between X and S");
	 }
}
		
	

public static void down(int sVertical, int sHorizontal, char[][] map, int xVertical, int xHorizontal) {
	System.out.print("d, ");
	findPath(sVertical +1, sHorizontal, map, xVertical, xHorizontal);
	
}
public static void up(int sVertical, int sHorizontal, char[][] map, int xVertical, int xHorizontal) {
	System.out.print("u, ");
	findPath(sVertical -1, sHorizontal, map, xVertical, xHorizontal);
}
public static void left(int sVertical, int sHorizontal, char[][] map, int xVertical, int xHorizontal) {
	System.out.print("l, ");
	findPath(sVertical, sHorizontal -1, map, xVertical, xHorizontal);
}
public static void right(int sVertical, int sHorizontal, char[][] map, int xVertical, int xHorizontal) {
	System.out.print("r, ");
	findPath(sVertical, sHorizontal +1, map, xVertical, xHorizontal);
}

public static int downPriority(int sVertical, int sHorizontal, char[][] map) {
	if(sVertical < map.length-1 && map[sVertical+1][sHorizontal] != '#') {
		if(map[sVertical+1][sHorizontal] == '.') {
			return 0;
		} else {
			return Character.getNumericValue(map[sVertical+1][sHorizontal]);
		}
	} else {
		return -1;
	} 
}

public static int upPriority(int sVertical, int sHorizontal, char[][] map) {
	if(sVertical > 0 && map[sVertical-1][sHorizontal] != '#') {
		if(map[sVertical-1][sHorizontal] == '.') {
			return 0;
		} else {
			return Character.getNumericValue(map[sVertical-1][sHorizontal]);
		}
	} else {
		return -1;
	}
}
public static int rightPriority(int sVertical, int sHorizontal, char[][] map) {
	if(sHorizontal < map[0].length-1 && map[sVertical][sHorizontal+1] != '#') {
		if(map[sVertical][sHorizontal+1] == '.') {
			return 0;
		} else {
			return Character.getNumericValue(map[sVertical][sHorizontal+1]);
		}
	} else {
		return -1;
	}
}
public static int leftPriority(int sVertical, int sHorizontal, char[][] map) {
	if(sHorizontal > 0 && map[sVertical][sHorizontal-1] != '#') {
		if(map[sVertical][sHorizontal-1] == '.') {
			return 0;
		} else {
			return Character.getNumericValue(map[sVertical][sHorizontal-1]);
		}
	} else {
		return -1;
	}
}

public static void mark(int sVertical, int sHorizontal, char[][] map) {
	if(map[sVertical][sHorizontal] == '.' || map[sVertical][sHorizontal] == 'S') {
		map[sVertical][sHorizontal] = '1';
	} else {
		int fieldValue = map[sVertical][sHorizontal];
		fieldValue++;
		map[sVertical][sHorizontal] = (char) fieldValue;
	}
}
	
}

